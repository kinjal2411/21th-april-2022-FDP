function externalAlert()
            {
                alert("HEllo internal script");
            }
function externalConfirm()
            {
                if(confirm("are you sure?"))
                  alert("yes");
                else
                    alert("No");
            }

function externalprompt()
            {
                var fname=prompt("enter Your Name");
                var lname=prompt("enter last name");
                alert(fname+""+lname);
            }